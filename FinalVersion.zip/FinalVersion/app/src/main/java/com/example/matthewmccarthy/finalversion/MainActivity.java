package com.example.matthewmccarthy.finalversion;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.spotify.sdk.android.authentication.AuthenticationClient;
import com.spotify.sdk.android.authentication.AuthenticationRequest;
import com.spotify.sdk.android.authentication.AuthenticationResponse;
import com.spotify.sdk.android.player.Config;
import com.spotify.sdk.android.player.ConnectionStateCallback;
import com.spotify.sdk.android.player.Error;
import com.spotify.sdk.android.player.Player;
import com.spotify.sdk.android.player.PlayerEvent;
import com.spotify.sdk.android.player.Spotify;
import com.spotify.sdk.android.player.SpotifyPlayer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.GenericArrayType;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import android.content.Intent;
import android.widget.EditText;

public class MainActivity extends Activity implements
        SpotifyPlayer.NotificationCallback, ConnectionStateCallback
{
    // TODO: Replace with your client ID
    private static final String CLIENT_ID = "26fc97455c624dd99dc1274a8c7a26ce";

    // TODO: Replace with your redirect URI
    private static final String REDIRECT_URI = "myapp://callback";

    private Player mPlayer;

    // Request code that will be used to verify if the result comes from correct activity
    // Can be any integer
    private static final int REQUEST_CODE = 1337;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // The only thing that's different is we added the 5 lines below.
        AuthenticationRequest.Builder builder = new AuthenticationRequest.Builder(CLIENT_ID, AuthenticationResponse.Type.TOKEN, REDIRECT_URI);
        builder.setScopes(new String[]{"user-read-private", "streaming"});
        AuthenticationRequest request = builder.build();

        AuthenticationClient.openLoginActivity(this, REQUEST_CODE, request);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        // Check if result comes from the correct activity
        // The next 19 lines of the code are what you need to copy & paste! :)
        if (requestCode == REQUEST_CODE) {
            AuthenticationResponse response = AuthenticationClient.getResponse(resultCode, intent);
            if (response.getType() == AuthenticationResponse.Type.TOKEN) {
                Config playerConfig = new Config(this, response.getAccessToken(), CLIENT_ID);
                Spotify.getPlayer(playerConfig, this, new SpotifyPlayer.InitializationObserver() {
                    @Override
                    public void onInitialized(SpotifyPlayer spotifyPlayer) {
                        mPlayer = spotifyPlayer;
                        mPlayer.addConnectionStateCallback(MainActivity.this);
                        mPlayer.addNotificationCallback(MainActivity.this);
                    }

                    @Override
                    public void onError(Throwable throwable) {
                        Log.e("MainActivity", "Could not initialize player: " + throwable.getMessage());
                    }
                });
            }
        }
    }

    @Override
    protected void onDestroy() {
        Spotify.destroyPlayer(this);
        super.onDestroy();
    }

    @Override
    public void onPlaybackEvent(PlayerEvent playerEvent) {
        Log.d("MainActivity", "Playback event received: " + playerEvent.name());
        switch (playerEvent) {
            // Handle event type as necessary
            default:
                break;
        }
    }

    @Override
    public void onPlaybackError(Error error) {
        Log.d("MainActivity", "Playback error received: " + error.name());
        switch (error) {
            // Handle error type as necessary
            default:
                break;
        }
    }

    @Override
    public void onLoggedIn() {
        setplaylist();
        firstPlay = true;
        Log.d("MainActivity", "User logged in");
    }

    @Override
    public void onLoggedOut() {
        Log.d("MainActivity", "User logged out");
    }

    @Override
    public void onLoginFailed(Error var1) {
        Log.d("MainActivity", "Login failed");
    }

    @Override
    public void onTemporaryError() {
        Log.d("MainActivity", "Temporary error occurred");
    }

    @Override
    public void onConnectionMessage(String message) {
        Log.d("MainActivity", "Received connection message: " + message);
    }

    static String ratings;


    public void yourMethodName(View v){
        ratings = formattedHash();
        startActivity(new Intent(MainActivity.this, Playeractivity.class));
    }

    public void runButton(View dumb) {
        // This is the line that plays a song.
        if (firstPlay==true) {
            mPlayer.playUri(null, playlist, 0, 0);
            firstPlay = false;
        } else {
            mPlayer.resume(null);
            updateTextView(mPlayer.getMetadata().currentTrack.name);
            updateTextView2(mPlayer.getMetadata().currentTrack.artistName);
        }
        Log.d("MainActivity", "Received connection message: " + "runButton");
    }
    public void skipButton(View dumb) {
        if (firstPlay) {
            ;
        } else {
            updateTextView(mPlayer.getMetadata().nextTrack.name);
            updateTextView2(mPlayer.getMetadata().nextTrack.artistName);
            mPlayer.skipToNext(null);
        }
        Log.d("MainActivity", "Received connection message: " + "skipButton");
    }
    public void pauseButton(View dumb) {
        mPlayer.pause(null);
        Log.d("MainActivity", "Received connection message: " + "pauseButton");
    }



    public void oneStar(View dumb) {
        if (firstPlay) {
            ;
        } else {
            setHashMap(mPlayer.getMetadata().currentTrack.name,"1");
        }
        Log.d("MainActivity", "Received connection message: " + "oneStar");
    }
    public void twoStar(View dumb) {
        if (firstPlay) {
            ;
        } else {
            setHashMap(mPlayer.getMetadata().currentTrack.name, "2");
        }
        Log.d("MainActivity", "Received connection message: " + "twoStar");
    }
    public void threeStar(View dumb) {
        if (firstPlay) {
            ;
        } else {
            setHashMap(mPlayer.getMetadata().currentTrack.name, "3");
        }
        Log.d("MainActivity", "Received connection message: " + "threeStar");
    }
    public void fourStar(View dumb) {
        if (firstPlay) {
            ;
        } else {
            setHashMap(mPlayer.getMetadata().currentTrack.name, "4");
        }
        Log.d("MainActivity", "Received connection message: " + "fourStar");
    }
    public void fiveStar(View dumb) {
        if (firstPlay) {
            ;
        } else {
            setHashMap(mPlayer.getMetadata().currentTrack.name, "5");
        }
        Log.d("MainActivity", "Received connection message: " + "fiveStar");
    }



    public void setHashMap(String song, String rating) {
        songs.put(mPlayer.getMetadata().currentTrack.name, rating);
    }
    public String getHashMapasString() {
        String hashMapString =songs.toString();
        return hashMapString;
    }
    public String formattedHash() {
        String five = "5 Star Ratings:";
        String four = "4 Star Ratings:";
        String three = "3 Star Ratings:";
        String two = "2 Star Ratings:";
        String one = "1 Star Ratings:";
        String temp = getHashMapasString();
        String[] songRatings = temp.split("[}{,=]");
        for(int i = 0; i < songRatings.length; i++) {
            if (songRatings[i].equals("1")) {
                one = one + songRatings[i-1] + ",";
            }
            if (songRatings[i].equals("2")) {
                two = two + songRatings[i-1] + ",";
            }
            if (songRatings[i].equals("3")) {
                three = three + songRatings[i-1] + ",";
            }
            if (songRatings[i].equals("4")) {
                four = four + songRatings[i-1] + ",";
            }
            if (songRatings[i].equals("5")) {
                five = five + songRatings[i-1] + ",";
            }
        }
        String organizedHash = five + "\n" + four + "\n" + three + "\n" + two + "\n" + one;
        Log.d("MainActivity", "Received connection message: " + organizedHash);
        return organizedHash;
    }




    public void setplaylist() {
        playlist = "spotify:user:spotify:playlist:37i9dQZF1DXaK0O81Xtkis";
    }
    public String getplaylist() {
        return playlist;
    }


    public void updateTextView(String toThis) {
        TextView textView = (TextView) findViewById(R.id.textView);
        textView.setText(toThis);
    }
    public void updateTextView2(String toThis) {
        TextView textView = (TextView) findViewById(R.id.textView3);
        textView.setText(toThis);
    }


    HashMap<String, String> songs = new HashMap<String, String>();
    String playlist;
    boolean firstPlay = true;


    public void logout(View view) {
        AuthenticationRequest.Builder builder =
                new AuthenticationRequest.Builder(CLIENT_ID, AuthenticationResponse.Type.TOKEN, REDIRECT_URI);

        builder.setScopes(new String[]{"streaming"});
        builder.setShowDialog(true);
        AuthenticationRequest request = builder.build();

        AuthenticationClient.openLoginActivity(this, REQUEST_CODE, request);
    }
}